公式レビュー未完了: setup/metadata。
