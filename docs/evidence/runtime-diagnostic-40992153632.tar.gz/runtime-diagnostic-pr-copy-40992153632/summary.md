公式レビュー未完了: setup/pr-copy。
